#!/bin/bash
# =============================================================================
# GARUDA MOVEMENT — HNS Chase Ecosystem
# build.sh — Compilation Script
# =============================================================================
# Version    : 1.0.0
# Reference  : GM_IMPLEMENTATION_PLAN.md §16
# =============================================================================
#
# USAGE:
#   ./tools/build.sh              # Compile all modules
#   ./tools/build.sh gm_account   # Compile a single module
#   ./tools/build.sh --check      # Compile-check only (no .smx output)
#   ./tools/build.sh --validate   # Validate load order, then compile all
#
# REQUIREMENTS:
#   - spcomp must be in PATH or set SPCOMP variable below
#   - Run from the repository root: ./tools/build.sh
#
# EXIT CODES:
#   0 = All modules compiled successfully
#   1 = One or more modules failed to compile
#   2 = Environment setup error
# =============================================================================

set -euo pipefail

# =============================================================================
# CONFIGURATION
# =============================================================================

# Path to spcomp binary. Override with environment variable if needed.
# Example: SPCOMP=/path/to/spcomp ./tools/build.sh
SPCOMP="${SPCOMP:-spcomp}"

# Repository root (script is in tools/, repo root is one level up)
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# Source and output directories
SCRIPTING_DIR="${REPO_ROOT}/addons/sourcemod/scripting"
INCLUDE_DIR="${SCRIPTING_DIR}/include"
OUTPUT_DIR="${REPO_ROOT}/addons/sourcemod/plugins/garuda"

# Compiler flags
SPCOMP_FLAGS="-O2 -v2 -i${INCLUDE_DIR} -D GM_VERSION=\\\"1.0.0\\\""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# =============================================================================
# CANONICAL LOAD ORDER
# This list is the authoritative compile order.
# It mirrors configs/plugins.ini exactly.
# DO NOT REORDER without an architecture review.
# =============================================================================

MODULES=(
    # Layer 2 — Feature Domains (dependency order)
    "gm_account"
    "gm_region"
    "gm_movement"
    "gm_team"
    "gm_gameplay"
    "gm_jumpstats"
    "gm_xp"
    "gm_rank"
    "gm_achievements"
    "gm_cosmetics"
    "gm_training"
    "gm_antiexploit"
    # Layer 3 — Presentation (load after all L2)
    "gm_hud"
    "gm_menu"
    "gm_commands"
    "gm_admin"
)

# =============================================================================
# FUNCTIONS
# =============================================================================

print_header() {
    echo ""
    echo -e "${CYAN}============================================================${NC}"
    echo -e "${CYAN}  GARUDA MOVEMENT — Build System v1.0.0${NC}"
    echo -e "${CYAN}============================================================${NC}"
    echo ""
}

check_environment() {
    echo -e "${CYAN}[ENV]${NC} Checking build environment..."

    # Check spcomp exists
    if ! command -v "${SPCOMP}" &>/dev/null; then
        echo -e "${RED}[ERROR]${NC} spcomp not found. Set SPCOMP=/path/to/spcomp or add to PATH."
        echo "        Download from: https://www.sourcemod.net/downloads.php"
        exit 2
    fi

    SPCOMP_VERSION=$(${SPCOMP} --version 2>&1 | head -1 || echo "unknown")
    echo -e "${GREEN}[OK]${NC}    spcomp: ${SPCOMP_VERSION}"

    # Check scripting directory exists
    if [ ! -d "${SCRIPTING_DIR}" ]; then
        echo -e "${RED}[ERROR]${NC} Scripting directory not found: ${SCRIPTING_DIR}"
        exit 2
    fi

    # Check include directory exists
    if [ ! -d "${INCLUDE_DIR}" ]; then
        echo -e "${RED}[ERROR]${NC} Include directory not found: ${INCLUDE_DIR}"
        exit 2
    fi

    # Check all required include files exist
    REQUIRED_INCLUDES=(
        "gm_core.inc"
        "gm_enums.inc"
        "gm_constants.inc"
        "gm_structs.inc"
        "gm_events.inc"
        "gm_natives.inc"
    )

    for inc in "${REQUIRED_INCLUDES[@]}"; do
        if [ ! -f "${INCLUDE_DIR}/${inc}" ]; then
            echo -e "${RED}[ERROR]${NC} Missing required include: ${inc}"
            exit 2
        fi
        echo -e "${GREEN}[OK]${NC}    Include found: ${inc}"
    done

    # Create output directory if it doesn't exist
    mkdir -p "${OUTPUT_DIR}"
    echo -e "${GREEN}[OK]${NC}    Output directory: ${OUTPUT_DIR}"
    echo ""
}

validate_load_order() {
    echo -e "${CYAN}[VALIDATE]${NC} Checking load order against plugins.ini..."

    PLUGINS_INI="${REPO_ROOT}/addons/sourcemod/configs/plugins.ini"

    if [ ! -f "${PLUGINS_INI}" ]; then
        echo -e "${YELLOW}[WARN]${NC}   plugins.ini not found. Skipping load order validation."
        return 0
    fi

    # Extract module names from plugins.ini (lines matching garuda/ pattern)
    mapfile -t INI_MODULES < <(grep -E "^garuda/" "${PLUGINS_INI}" | sed 's|garuda/||g' | tr -d ' \r')

    # Compare with canonical order
    local MISMATCH=0
    for i in "${!MODULES[@]}"; do
        EXPECTED="${MODULES[$i]}"
        ACTUAL="${INI_MODULES[$i]:-MISSING}"

        if [ "${EXPECTED}" != "${ACTUAL}" ]; then
            echo -e "${RED}[MISMATCH]${NC} Position $((i+1)): expected '${EXPECTED}', found '${ACTUAL}'"
            MISMATCH=1
        fi
    done

    if [ $MISMATCH -eq 0 ]; then
        echo -e "${GREEN}[OK]${NC}    Load order matches canonical order (${#MODULES[@]} modules)."
    else
        echo -e "${RED}[ERROR]${NC} plugins.ini load order does not match build.sh canonical order."
        echo "        Update plugins.ini to match the MODULES array in build.sh."
        exit 1
    fi
    echo ""
}

check_hardcoded_strings() {
    echo -e "${CYAN}[STRINGS]${NC} Scanning for hardcoded player-facing strings..."

    local VIOLATIONS=0

    for module in "${MODULES[@]}"; do
        SP_FILE="${SCRIPTING_DIR}/${module}.sp"
        if [ ! -f "${SP_FILE}" ]; then
            continue
        fi

        # Pattern: PrintToChat or PrintHintText calls with literal quoted strings
        # that don't start with the GM_COLOR constants or aren't using %T (translation)
        HITS=$(grep -n "PrintToChat\|PrintHintText\|PrintToAll" "${SP_FILE}" \
               | grep -v "%T\|GM_Color\|GM_Lang\|//\|^\s*//" \
               | grep '"[A-Z]' || true)

        if [ -n "$HITS" ]; then
            echo -e "${YELLOW}[WARN]${NC}   Potential hardcoded strings in ${module}.sp:"
            echo "$HITS" | while IFS= read -r line; do
                echo "          $line"
            done
            VIOLATIONS=$((VIOLATIONS + 1))
        fi
    done

    if [ $VIOLATIONS -eq 0 ]; then
        echo -e "${GREEN}[OK]${NC}    No hardcoded player-facing strings detected."
    else
        echo -e "${YELLOW}[WARN]${NC}   ${VIOLATIONS} file(s) with potential hardcoded strings."
        echo "          Review manually. False positives possible."
    fi
    echo ""
}

compile_module() {
    local MODULE=$1
    local SP_FILE="${SCRIPTING_DIR}/${MODULE}.sp"
    local SMX_FILE="${OUTPUT_DIR}/${MODULE}.smx"

    if [ ! -f "${SP_FILE}" ]; then
        echo -e "${YELLOW}[SKIP]${NC}   ${MODULE}.sp not found — skipping."
        return 0
    fi

    printf "  %-30s" "${MODULE}.sp"

    # Run spcomp
    COMPILE_OUTPUT=$(eval "${SPCOMP} ${SPCOMP_FLAGS} \"${SP_FILE}\" -o \"${SMX_FILE}\"" 2>&1)
    COMPILE_EXIT=$?

    if [ $COMPILE_EXIT -eq 0 ]; then
        # Check for warnings in output
        WARNING_COUNT=$(echo "$COMPILE_OUTPUT" | grep -c "warning" || true)
        if [ "$WARNING_COUNT" -gt 0 ]; then
            echo -e "${YELLOW}[WARN ${WARNING_COUNT}]${NC}"
            echo "$COMPILE_OUTPUT" | grep "warning" | while IFS= read -r line; do
                echo "               $line"
            done
        else
            echo -e "${GREEN}[OK]${NC}"
        fi
        return 0
    else
        echo -e "${RED}[FAIL]${NC}"
        echo "$COMPILE_OUTPUT" | while IFS= read -r line; do
            echo "               $line"
        done
        return 1
    fi
}

# =============================================================================
# MAIN
# =============================================================================

print_header

# Parse arguments
SINGLE_MODULE=""
CHECK_ONLY=0
DO_VALIDATE=0

for arg in "$@"; do
    case "$arg" in
        --check)    CHECK_ONLY=1 ;;
        --validate) DO_VALIDATE=1 ;;
        gm_*)       SINGLE_MODULE="$arg" ;;
        *)          echo -e "${RED}[ERROR]${NC} Unknown argument: $arg"; exit 2 ;;
    esac
done

# Environment check (always runs)
check_environment

# Load order validation
if [ $DO_VALIDATE -eq 1 ] || [ -z "$SINGLE_MODULE" ]; then
    validate_load_order
fi

# String scan (on full builds)
if [ -z "$SINGLE_MODULE" ]; then
    check_hardcoded_strings
fi

# Compilation
echo -e "${CYAN}[BUILD]${NC} Compiling modules..."
echo ""

TOTAL=0
PASSED=0
FAILED=0
SKIPPED=0
FAILED_MODULES=()

if [ -n "$SINGLE_MODULE" ]; then
    # Single module compile
    COMPILE_LIST=("$SINGLE_MODULE")
else
    # Full build — compile in canonical load order
    COMPILE_LIST=("${MODULES[@]}")
fi

for MODULE in "${COMPILE_LIST[@]}"; do
    TOTAL=$((TOTAL + 1))
    SP_FILE="${SCRIPTING_DIR}/${MODULE}.sp"

    if [ ! -f "${SP_FILE}" ]; then
        SKIPPED=$((SKIPPED + 1))
        printf "  %-30s" "${MODULE}.sp"
        echo -e "${YELLOW}[SKIP]${NC}   (file not found)"
        continue
    fi

    if compile_module "$MODULE"; then
        PASSED=$((PASSED + 1))
    else
        FAILED=$((FAILED + 1))
        FAILED_MODULES+=("$MODULE")
    fi
done

# Summary
echo ""
echo -e "${CYAN}============================================================${NC}"
echo -e "  Results: ${GREEN}${PASSED} passed${NC}  ${YELLOW}${SKIPPED} skipped${NC}  ${RED}${FAILED} failed${NC}  (${TOTAL} total)"
echo -e "${CYAN}============================================================${NC}"

if [ $FAILED -gt 0 ]; then
    echo ""
    echo -e "${RED}Failed modules:${NC}"
    for m in "${FAILED_MODULES[@]}"; do
        echo "  - $m"
    done
    echo ""
    exit 1
fi

if [ $PASSED -gt 0 ]; then
    echo ""
    echo -e "${GREEN}Build successful.${NC} Output: ${OUTPUT_DIR}/"
fi

echo ""
exit 0
