#!/bin/bash
# =============================================================================
# GARUDA MOVEMENT — HNS Chase Ecosystem
# check_strings.sh — Hardcoded String Scanner
# =============================================================================
# Version    : 1.0.0
# Reference  : GM_IMPLEMENTATION_PLAN.md §13.3
# =============================================================================
#
# Scans all .sp files for hardcoded player-facing strings that should be
# localized through the Language System.
#
# A Phase 9 exit criterion is: zero violations from this script.
#
# USAGE:
#   ./tools/check_strings.sh          # Scan all modules
#   ./tools/check_strings.sh gm_xp    # Scan a single module
# =============================================================================

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SCRIPTING_DIR="${REPO_ROOT}/addons/sourcemod/scripting"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

MODULES=(
    "gm_account" "gm_region" "gm_movement" "gm_team" "gm_gameplay"
    "gm_jumpstats" "gm_xp" "gm_rank" "gm_achievements" "gm_cosmetics"
    "gm_training" "gm_antiexploit" "gm_hud" "gm_menu" "gm_commands" "gm_admin"
)

TOTAL_VIOLATIONS=0
FILES_WITH_VIOLATIONS=0

echo ""
echo -e "${CYAN}============================================================${NC}"
echo -e "${CYAN}  GARUDA MOVEMENT — Hardcoded String Scanner${NC}"
echo -e "${CYAN}============================================================${NC}"
echo ""

SCAN_LIST=("${MODULES[@]}")
if [ -n "${1:-}" ]; then
    SCAN_LIST=("$1")
fi

for MODULE in "${SCAN_LIST[@]}"; do
    SP_FILE="${SCRIPTING_DIR}/${MODULE}.sp"
    [ -f "$SP_FILE" ] || continue

    # Detect PrintToChat / PrintHintText / PrintToAll calls with raw string literals
    # (not using %T translation token, not using GM_Lang_ functions, not comments)
    VIOLATIONS=$(grep -n \
        -E '(PrintToChat|PrintHintText|PrintToAll|PrintToServer)\s*\(' \
        "$SP_FILE" \
        | grep -v '%T' \
        | grep -v 'GM_Lang_' \
        | grep -v '^\s*//' \
        | grep -v '//.*Print' \
        | grep '"[A-Z\[]' \
        || true)

    if [ -n "$VIOLATIONS" ]; then
        FILES_WITH_VIOLATIONS=$((FILES_WITH_VIOLATIONS + 1))
        VIOLATION_COUNT=$(echo "$VIOLATIONS" | wc -l)
        TOTAL_VIOLATIONS=$((TOTAL_VIOLATIONS + VIOLATION_COUNT))

        echo -e "${RED}[FAIL]${NC} ${MODULE}.sp — ${VIOLATION_COUNT} violation(s):"
        echo "$VIOLATIONS" | while IFS= read -r line; do
            echo "       Line $line"
        done
        echo ""
    else
        echo -e "${GREEN}[OK]${NC}   ${MODULE}.sp"
    fi
done

echo ""
echo -e "${CYAN}============================================================${NC}"
if [ $TOTAL_VIOLATIONS -eq 0 ]; then
    echo -e "${GREEN}  PASS — No hardcoded strings detected.${NC}"
else
    echo -e "${RED}  FAIL — ${TOTAL_VIOLATIONS} violation(s) in ${FILES_WITH_VIOLATIONS} file(s).${NC}"
    echo -e "  Replace hardcoded strings with GM_Lang_PrintToChat() calls."
    exit 1
fi
echo -e "${CYAN}============================================================${NC}"
echo ""
