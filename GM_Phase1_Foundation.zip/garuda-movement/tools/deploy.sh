#!/bin/bash
# =============================================================================
# GARUDA MOVEMENT — HNS Chase Ecosystem
# deploy.sh — Server Deployment Script
# =============================================================================
# Version    : 1.0.0
# Reference  : GM_IMPLEMENTATION_PLAN.md §16.4
# =============================================================================
#
# USAGE:
#   ./tools/deploy.sh                     # Deploy all compiled modules
#   ./tools/deploy.sh gm_account          # Deploy a single module
#   ./tools/deploy.sh --configs-only      # Deploy config files only (no .smx)
#   ./tools/deploy.sh --reload gm_xp      # Deploy + issue sm reload for module
#
# REQUIREMENTS:
#   - Set SERVER_DIR to your CSS server's addons/sourcemod directory.
#   - For remote deployment, set DEPLOY_MODE=rsync and configure SSH_TARGET.
#
# =============================================================================

set -euo pipefail

# =============================================================================
# CONFIGURATION — Edit these for your environment
# =============================================================================

# Local CSS server SourceMod directory (for local deployments)
SERVER_DIR="${SERVER_DIR:-/opt/css-server/addons/sourcemod}"

# Deployment mode: "local" or "rsync"
DEPLOY_MODE="${DEPLOY_MODE:-local}"

# SSH target for rsync mode (e.g. "user@server.example.com")
SSH_TARGET="${SSH_TARGET:-}"

# RCON settings for sm reload commands (requires rcon tool)
RCON_HOST="${RCON_HOST:-127.0.0.1}"
RCON_PORT="${RCON_PORT:-27015}"
RCON_PASS="${RCON_PASS:-}"

# Repository root
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="${REPO_ROOT}/addons/sourcemod"
PLUGINS_SRC="${BUILD_DIR}/plugins/garuda"

# Colors
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

# =============================================================================
# MODULE LIST (same as build.sh — must stay in sync)
# =============================================================================

MODULES=(
    "gm_account" "gm_region" "gm_movement" "gm_team" "gm_gameplay"
    "gm_jumpstats" "gm_xp" "gm_rank" "gm_achievements" "gm_cosmetics"
    "gm_training" "gm_antiexploit" "gm_hud" "gm_menu" "gm_commands" "gm_admin"
)

# =============================================================================
# FUNCTIONS
# =============================================================================

deploy_file() {
    local SRC=$1
    local DEST_DIR=$2

    if [ ! -f "$SRC" ]; then
        echo -e "${YELLOW}[SKIP]${NC}   $(basename $SRC) (source not found)"
        return 0
    fi

    mkdir -p "$DEST_DIR"

    if [ "$DEPLOY_MODE" = "rsync" ]; then
        rsync -avz --progress "$SRC" "${SSH_TARGET}:${DEST_DIR}/" 2>&1
    else
        cp -v "$SRC" "$DEST_DIR/"
    fi
}

deploy_configs() {
    echo -e "${CYAN}[CONFIGS]${NC} Deploying configuration files..."
    local CFG_DEST="${SERVER_DIR}/configs"

    for cfg in "${BUILD_DIR}"/configs/gm_*.cfg; do
        [ -f "$cfg" ] || continue
        local filename=$(basename "$cfg")
        if [ ! -f "${CFG_DEST}/${filename}" ]; then
            deploy_file "$cfg" "$CFG_DEST"
            echo -e "${GREEN}[OK]${NC}    Deployed: ${filename}"
        else
            echo -e "${YELLOW}[SKIP]${NC}   ${filename} already exists (not overwriting live config)"
        fi
    done

    # plugins.ini: always deploy if not present
    if [ ! -f "${CFG_DEST}/plugins.ini" ]; then
        deploy_file "${BUILD_DIR}/configs/plugins.ini" "$CFG_DEST"
        echo -e "${GREEN}[OK]${NC}    Deployed: plugins.ini"
    else
        echo -e "${YELLOW}[SKIP]${NC}   plugins.ini already exists"
    fi
}

deploy_translations() {
    echo -e "${CYAN}[TRANS]${NC} Deploying translation files..."
    local TRANS_DEST="${SERVER_DIR}/translations"
    mkdir -p "$TRANS_DEST"

    for phrases in "${BUILD_DIR}"/translations/*.phrases.txt; do
        [ -f "$phrases" ] || continue
        deploy_file "$phrases" "$TRANS_DEST"
        echo -e "${GREEN}[OK]${NC}    Deployed: $(basename $phrases)"
    done
}

# =============================================================================
# MAIN
# =============================================================================

echo ""
echo -e "${CYAN}============================================================${NC}"
echo -e "${CYAN}  GARUDA MOVEMENT — Deploy Script v1.0.0${NC}"
echo -e "${CYAN}  Mode: ${DEPLOY_MODE} | Target: ${SERVER_DIR}${NC}"
echo -e "${CYAN}============================================================${NC}"
echo ""

CONFIGS_ONLY=0
SINGLE_MODULE=""
DO_RELOAD=""

for arg in "$@"; do
    case "$arg" in
        --configs-only) CONFIGS_ONLY=1 ;;
        --reload)       DO_RELOAD=1 ;;
        gm_*)           SINGLE_MODULE="$arg" ;;
    esac
done

# Deploy configs
deploy_configs
echo ""

# Deploy translations
deploy_translations
echo ""

# Deploy .smx files
if [ $CONFIGS_ONLY -eq 0 ]; then
    echo -e "${CYAN}[PLUGINS]${NC} Deploying plugin binaries..."
    PLUGINS_DEST="${SERVER_DIR}/plugins/garuda"
    mkdir -p "$PLUGINS_DEST"

    if [ -n "$SINGLE_MODULE" ]; then
        DEPLOY_LIST=("$SINGLE_MODULE")
    else
        DEPLOY_LIST=("${MODULES[@]}")
    fi

    for MODULE in "${DEPLOY_LIST[@]}"; do
        SMX="${PLUGINS_SRC}/${MODULE}.smx"
        if [ -f "$SMX" ]; then
            deploy_file "$SMX" "$PLUGINS_DEST"
            echo -e "${GREEN}[OK]${NC}    Deployed: ${MODULE}.smx"
        else
            echo -e "${YELLOW}[SKIP]${NC}   ${MODULE}.smx not compiled yet"
        fi
    done
fi

echo ""
echo -e "${GREEN}Deployment complete.${NC}"
echo ""
