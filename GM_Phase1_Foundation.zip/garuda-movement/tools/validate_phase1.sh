#!/bin/bash
# =============================================================================
# GARUDA MOVEMENT — HNS Chase Ecosystem
# validate_phase1.sh — Phase 1 Exit Criteria Validation
# =============================================================================
# Version    : 1.0.0
# Reference  : GM_IMPLEMENTATION_PLAN.md §2 (Phase 1 Exit Criteria)
# =============================================================================
#
# Runs all Phase 1 exit criteria checks. All checks must pass before
# development can advance to Phase 2 (Account + Database).
#
# Phase 1 Exit Criteria:
#   1. All six include files compile without warnings.
#   2. All 16 module stubs compile without errors.
#   3. Build script runs cleanly.
#   4. Load order is consistent between build.sh and plugins.ini.
#   5. All required directories and config files exist.
#
# USAGE:
#   ./tools/validate_phase1.sh
#
# EXIT CODES:
#   0 = All Phase 1 criteria met — ready to begin Phase 2
#   1 = One or more criteria not met
# =============================================================================

set -uo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

PASS=0
FAIL=0

check() {
    local DESC=$1
    local RESULT=$2  # "pass" or "fail"
    local DETAIL="${3:-}"

    if [ "$RESULT" = "pass" ]; then
        PASS=$((PASS + 1))
        printf "  ${GREEN}[PASS]${NC} %s\n" "$DESC"
    else
        FAIL=$((FAIL + 1))
        printf "  ${RED}[FAIL]${NC} %s\n" "$DESC"
        if [ -n "$DETAIL" ]; then
            echo "         → $DETAIL"
        fi
    fi
}

echo ""
echo -e "${CYAN}============================================================${NC}"
echo -e "${CYAN}  GARUDA MOVEMENT — Phase 1 Validation${NC}"
echo -e "${CYAN}============================================================${NC}"
echo ""

# =============================================================================
# CHECK 1: Required directory structure
# =============================================================================
echo -e "${CYAN}[1/5]${NC} Directory structure..."

REQUIRED_DIRS=(
    "addons/sourcemod/scripting/include"
    "addons/sourcemod/plugins/garuda"
    "addons/sourcemod/configs"
    "addons/sourcemod/translations"
    "addons/sourcemod/logs"
    "addons/sourcemod/data/geoip"
    "maps/metadata"
    "tools"
    "docs"
)

for dir in "${REQUIRED_DIRS[@]}"; do
    if [ -d "${REPO_ROOT}/${dir}" ]; then
        check "Directory: ${dir}" "pass"
    else
        check "Directory: ${dir}" "fail" "Run: mkdir -p ${REPO_ROOT}/${dir}"
    fi
done
echo ""

# =============================================================================
# CHECK 2: Required include files
# =============================================================================
echo -e "${CYAN}[2/5]${NC} Include files..."

REQUIRED_INCLUDES=(
    "addons/sourcemod/scripting/include/gm_core.inc"
    "addons/sourcemod/scripting/include/gm_enums.inc"
    "addons/sourcemod/scripting/include/gm_constants.inc"
    "addons/sourcemod/scripting/include/gm_structs.inc"
    "addons/sourcemod/scripting/include/gm_events.inc"
    "addons/sourcemod/scripting/include/gm_natives.inc"
)

for inc in "${REQUIRED_INCLUDES[@]}"; do
    if [ -f "${REPO_ROOT}/${inc}" ]; then
        check "Include: $(basename $inc)" "pass"
    else
        check "Include: $(basename $inc)" "fail" "File missing: ${inc}"
    fi
done
echo ""

# =============================================================================
# CHECK 3: Required config files
# =============================================================================
echo -e "${CYAN}[3/5]${NC} Configuration files..."

REQUIRED_CONFIGS=(
    "addons/sourcemod/configs/gm_config.cfg"
    "addons/sourcemod/configs/gm_gameplay.cfg"
    "addons/sourcemod/configs/gm_team.cfg"
    "addons/sourcemod/configs/gm_jumpstats.cfg"
    "addons/sourcemod/configs/gm_xp.cfg"
    "addons/sourcemod/configs/gm_rank.cfg"
    "addons/sourcemod/configs/gm_training.cfg"
    "addons/sourcemod/configs/plugins.ini"
)

for cfg in "${REQUIRED_CONFIGS[@]}"; do
    if [ -f "${REPO_ROOT}/${cfg}" ]; then
        check "Config: $(basename $cfg)" "pass"
    else
        check "Config: $(basename $cfg)" "fail" "File missing: ${cfg}"
    fi
done
echo ""

# =============================================================================
# CHECK 4: Module stub .sp files exist
# =============================================================================
echo -e "${CYAN}[4/5]${NC} Module stub files..."

MODULES=(
    "gm_account" "gm_region" "gm_movement" "gm_team" "gm_gameplay"
    "gm_jumpstats" "gm_xp" "gm_rank" "gm_achievements" "gm_cosmetics"
    "gm_training" "gm_antiexploit" "gm_hud" "gm_menu" "gm_commands" "gm_admin"
)

for module in "${MODULES[@]}"; do
    SP="${REPO_ROOT}/addons/sourcemod/scripting/${module}.sp"
    if [ -f "$SP" ]; then
        check "Stub: ${module}.sp" "pass"
    else
        check "Stub: ${module}.sp" "fail" "File missing"
    fi
done
echo ""

# =============================================================================
# CHECK 5: Compilation (requires spcomp)
# =============================================================================
echo -e "${CYAN}[5/5]${NC} Compilation check..."

if ! command -v "${SPCOMP:-spcomp}" &>/dev/null; then
    check "spcomp available" "fail" \
          "spcomp not found in PATH. Set SPCOMP=/path/to/spcomp"
    echo -e "       ${YELLOW}Skipping compilation checks (spcomp not available).${NC}"
    echo -e "       ${YELLOW}Install SourceMod to complete Phase 1 validation.${NC}"
else
    check "spcomp available" "pass"

    # Run build script
    BUILD_OUTPUT=$("${REPO_ROOT}/tools/build.sh" 2>&1)
    BUILD_EXIT=$?

    if [ $BUILD_EXIT -eq 0 ]; then
        check "Full build: all modules compile" "pass"
    else
        check "Full build: all modules compile" "fail" "See build output above"
        echo "$BUILD_OUTPUT" | tail -20
    fi

    # Load order validation
    VALIDATE_OUTPUT=$("${REPO_ROOT}/tools/build.sh" --validate 2>&1)
    VALIDATE_EXIT=$?

    if [ $VALIDATE_EXIT -eq 0 ]; then
        check "Load order: build.sh matches plugins.ini" "pass"
    else
        check "Load order: build.sh matches plugins.ini" "fail"
    fi
fi
echo ""

# =============================================================================
# RESULT
# =============================================================================
echo -e "${CYAN}============================================================${NC}"
echo -e "  Results: ${GREEN}${PASS} passed${NC}  ${RED}${FAIL} failed${NC}"
echo -e "${CYAN}============================================================${NC}"

if [ $FAIL -eq 0 ]; then
    echo ""
    echo -e "${GREEN}  ✓ Phase 1 complete. Ready to begin Phase 2.${NC}"
    echo -e "${GREEN}  Next: Implement gm_account.sp and gm_region.sp${NC}"
    echo ""
    exit 0
else
    echo ""
    echo -e "${RED}  ✗ Phase 1 incomplete. Resolve ${FAIL} failure(s) above.${NC}"
    echo ""
    exit 1
fi
