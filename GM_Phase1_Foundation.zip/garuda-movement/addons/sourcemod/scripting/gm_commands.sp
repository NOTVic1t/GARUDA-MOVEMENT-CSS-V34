// =============================================================================
// GARUDA MOVEMENT — HNS Chase Ecosystem
// gm_commands.sp — Commands Module
// =============================================================================
// Version    : 1.0.0 (Phase 1 Stub)
// Layer      : 3 — Presentation
// Description: Command registration and routing
// Reference  : GM_PLUGIN_ARCHITECTURE.md §6
//              GM_IMPLEMENTATION_PLAN.md Phase 
// =============================================================================
//
// PHASE 1 STUB — COMPILE VALIDATION ONLY
//
// This file is a compile-time stub. Its sole purpose is to verify that
// gm_core.inc and all its sub-includes compile without errors against this
// module's entry point.
//
// Implementation begins in the phase designated for this module.
// See GM_IMPLEMENTATION_PLAN.md for the phase schedule.
//
// DO NOT add implementation logic to this file during Phase 1.
// =============================================================================

#include <gm_core>

// Plugin metadata — required by SourceMod
public Plugin myinfo =
{
    name        = "Garuda Movement — Commands Module",
    author      = "Garuda Movement Development Team",
    description = "Command registration and routing",
    version     = GM_VERSION,
    url         = ""
};

// =============================================================================
// PHASE 1 ENTRY POINTS (stubs only)
// =============================================================================

/**
 * OnPluginStart — called when the plugin is loaded.
 * Phase 1: logs load confirmation only.
 * Full implementation: Phase .
 */
public void OnPluginStart()
{
    GM_Log_Info("commands", "Module loaded (Phase 1 stub). Version: %s", GM_VERSION);
}

/**
 * OnPluginEnd — called when the plugin is unloaded.
 * Phase 1: logs unload confirmation only.
 */
public void OnPluginEnd()
{
    GM_Log_Info("commands", "Module unloaded.");
}

// =============================================================================
// END OF PHASE 1 STUB
// Implementation for this module begins in Phase .
// See GM_IMPLEMENTATION_PLAN.md §2 for phase entry/exit criteria.
// =============================================================================
